public class Agregador {

    public void seiCalcularAreas(FormaGeometrica forma){
        System.out.println("Área = " + forma.calculaArea());
    }
}
