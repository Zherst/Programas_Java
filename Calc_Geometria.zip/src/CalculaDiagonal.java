public interface CalculaDiagonal {
    public double calcDiagonal();
}
