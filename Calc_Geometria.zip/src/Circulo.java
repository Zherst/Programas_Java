public class Circulo extends FormaGeometrica {
    private float raio;
    private String cor;

    public float getRaio()  {return this.raio;}

    public boolean  setRaio(float raio) {
        if (raio <= 0) {return false;}
        this.raio = raio;
        return true;
    }

    public Circulo (float raio, String cor){
        super(cor);
        if(!setRaio(raio)) {
            System.out.println("Erro");
            System.exit(0);
        }
    }

    @Override
    public double calculaArea(){
        return Math.PI * this.raio * this.raio;
    }

}
