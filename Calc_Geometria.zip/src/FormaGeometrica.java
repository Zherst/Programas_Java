public abstract class FormaGeometrica {
   // float area;
  //  float perimetro;

    private String cor;
    public void setCor(String cor){ this.cor = cor;}

    public String getCor(){ return this.cor;}

    public FormaGeometrica(String cor)
    {
        this.cor = cor;
    }

    //metodo abstrato
    public abstract double calculaArea();
}
