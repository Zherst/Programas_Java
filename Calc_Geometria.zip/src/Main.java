//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello and welcome!");
        Circulo c = new Circulo(10,"verde");
        Quadrado q = new Quadrado(10, "vermelho");
        Agregador agg = new Agregador();

        agg.seiCalcularAreas(c);
        agg.seiCalcularAreas(q);

    }

}

