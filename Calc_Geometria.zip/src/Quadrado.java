public class Quadrado extends FormaGeometrica implements CalculaDiagonal {
    private float lado;
    private String cor;

    public float getLado()  {return this.lado;}
    public String getCor()    {return this.cor;}
    public void setCor(String cor){this.cor = cor;}

    public boolean  setLado(float lado) {
        if (lado <= 0) {return false;}
        this.lado = lado;
        return true;
    }

    public Quadrado (float lado, String cor){
        super(cor);
        if(!setLado(lado)) {
            System.out.println("Erro");
            System.exit(0);
        }
    }

    @Override
    public double calculaArea(){
        return this.lado * this.lado;
    }

    public double calcDiagonal(){
        return (lado * Math.sqrt(2));
    }

}
