public class EmailSubscriber implements Subscriber{
    private String email;

    public EmailSubscriber(String email){
        this.email = email;
    }

    @Override
    public void Update(String message) {
        System.out.println("Enviando email para " + email + ": " + message);
    }
}
