public class LogSubscriber implements Subscriber{
    @Override
    public void Update(String message) {
        System.out.println("Registrando log: " + message);
    }
}
