public class Main {
    public static  void main(String[] args){
        Publisher publisher = new Publisher();

        Subscriber email1 = new EmailSubscriber("user1");
        Subscriber email2 = new EmailSubscriber("user2");
        Subscriber logger  = new LogSubscriber();

        publisher.subscribe(email1);
        publisher.subscribe(email2);
        publisher.subscribe(logger);

        publisher.publish("Novo evento disponível");
        publisher.publish("Atualização de status: completo.");

        publisher.unsubscribe(email2);
        publisher.publish("Conhõ");
    }
}
