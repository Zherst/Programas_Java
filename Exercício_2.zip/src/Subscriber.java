public interface Subscriber {
    void Update(String message);
}
