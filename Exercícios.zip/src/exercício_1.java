//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.ArrayList;
import java.util.Scanner;

public class exercício_1 {
    int valor1 = 0;
    int valor2 = 0;
    public static void main(String[] args){

        ArrayList<Integer> lista = new ArrayList<>();
        int valor = 0;
        int resultado = 0;
        System.out.println("Digite 2 números para multiplicar: ");

        Scanner scanner = new Scanner(System.in);

        for (int i = 1; i <= 2; i++) {
            System.out.println("Digite o " + i + "º número: ");
            valor = scanner.nextInt();
            lista.add(valor);
        }

        for (int i = 0; i <= lista.toArray().length - 1; i++) {

            int n = lista.get(i);
            if (resultado <= 0){
                resultado = n;
                System.out.print(n + " x ");
            }
            else{
                resultado *= n;
                if (i == lista.toArray().length){
                    System.out.print(n + " x ");
                }
                else {
                    System.out.println(n + " = " + resultado);
                }
            }
        }

        if (resultado % 2 == 0){
            System.out.println("resultado: " + resultado + " é Par");
        }
        else {
            System.out.println("resultado: " + resultado + " é Ímpar");
        }
    }

}