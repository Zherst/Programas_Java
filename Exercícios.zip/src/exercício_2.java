import java.util.ArrayList;
import java.util.Scanner;
public class exercício_2 {
    public static void main(String[] args) {

        ArrayList<Integer> lista = new ArrayList<>();
        ArrayList<Integer> lista2 = new ArrayList<>();

        System.out.println("Digite 10 números diferentes: ");

        Scanner scanner = new Scanner(System.in);

        for (int i = 1; i <= 10; i++) {
            System.out.println("Digite o " + i + "º número: ");
            int valor = scanner.nextInt();
            lista.add(valor);
        }
        for (int n : lista){
            System.out.println( n + " x 2 = " + n*2);
        }

        int count = 1;
        while (count <= 10){
            System.out.println("Digite o " + count + "º número: ");
            int valor = scanner.nextInt();
            lista2.add(valor);
            count ++;
        }

        for (int n : lista2){
            System.out.println( n + " x 2 =" + n*2);
        }
    }
}
