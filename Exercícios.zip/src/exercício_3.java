import java.util.ArrayList;
import java.util.Scanner;
public class exercício_3 {
    public static void main(String[] args) {

//        String[] lista = new String[3];
        ArrayList<String> lista = new ArrayList<>();

        System.out.println("Digite 3 nomes diferentes: ");

        Scanner scanner = new Scanner(System.in);


        for (int i = 1; i <= 3; i ++) {
            System.out.println("Dígite o " + i + "º nome");
            String nome = scanner.next();
            lista.add(nome);
        }

        for(String n : lista){
            System.out.println("\nO nome " + n + " tem " + n.length() + " caracteres" );
        }
    }
}