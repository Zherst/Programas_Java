import java.util.Scanner;

public abstract class Item {
    protected EnumBonusItem bonus;
    Scanner scanner = new Scanner(System.in);

    Item(EnumBonusItem bonus){
        this.bonus = bonus;
    }

    public int getBonus(){ return bonus.getValor(); }

    public abstract void aplicaBonusHeroi(Heroi heroi);
    public abstract void retirarBonusHeroi(Heroi heroi);
    public abstract void imprimeDescricao();
    public abstract String getTipo();

    public void juntar(Heroi heroi)
    {
        System.out.println("\033[H\033[2J");
        imprimeDescricao();
        System.out.println("Digite 'd' para substituir a mão Direita, 'e' para Esquerda ou 'n' para ignorar.");
        String resposta = scanner.nextLine().trim().toLowerCase();
        switch (resposta){
            case "d":
                if(heroi.getMaoDireita() != null){
                    heroi.getMaoDireita().retirarBonusHeroi(heroi);
                }
                heroi.setMaoDireita(this);
                System.out.println("O herói está com "+ getTipo() +" na mão direita");
                this.aplicaBonusHeroi(heroi);
                break;
            case  "e":
                if(heroi.getMaoEsquerda() != null){
                    heroi.getMaoEsquerda().retirarBonusHeroi(heroi);
                }
                heroi.setMaoEsquerda(this);
                System.out.println("O herói está com "+ getTipo() +" na mão esquerda");
                this.aplicaBonusHeroi(heroi);
                break;
            case "n":
                System.out.println("Herói ignorou " + getTipo());
                break;
            default:
                System.out.println("Comando ñ aceito");
                juntar(heroi);
        }

    }
    
}
