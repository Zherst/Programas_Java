import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Mapa {
    private char[][] matriz;
    private int numeroLinhas, numeroColunas;
    //Heroi
    EntidadeFactory heroiFactory = new HeroiFactory();
    Heroi heroi = (Heroi) heroiFactory.criarEntidade();

    //Mostros
    MonstroFactory bichoPapaoFactory = new BichoPapaoFactory();
    MonstroFactory curupiraFactory = new CurupiraFactory();

    MonstroExecute bichoPapaoExecute = new MonstroExecute(bichoPapaoFactory);
    MonstroExecute curupiraExecute = new MonstroExecute(curupiraFactory);
    //Ajudantes
    AjudanteFactory anaoFactory = new AnaoFactory();
    AjudanteFactory duendeFactory = new DuendeFactory();

    AjudanteExecute anaoExecute = new AjudanteExecute(anaoFactory);
    AjudanteExecute duendeExecute = new AjudanteExecute(duendeFactory);
    //Items
    ItemFactory espadaFactory = new EspadaFactory();
    ItemFactory escudoFactory = new EscudoFactory();
    ItemFactory curaFactory = new CuraFactory();

    ItemExecute espadaExecute = new ItemExecute(espadaFactory);
    ItemExecute escudoExecute = new ItemExecute(escudoFactory);
    ItemExecute curaExecute = new ItemExecute(curaFactory);

    Mapa(String nomeArquivo, int linhas, int colunas)
    {
        this.numeroColunas = colunas;
        this.numeroLinhas = linhas;
        alocaMatriz();
        this.heroi = new Heroi();

        try (BufferedReader br = new BufferedReader(new FileReader(nomeArquivo))){
            int c;
            int i = 0, j = 0;

            while ((c = br.read()) != -1 && i < linhas){
                if (c == '\n' || c == '\r'){
                    continue;
                }
                this.matriz[i][j] = (char) c;
                j++;
                if (j == colunas){
                    j = 0;
                    i++;
                }
            }

        } catch (IOException e){
            System.out.println("Erro ao abrir o arquivo: " + e.getMessage());
        }

    }

    public void imprimeMapa()
    {
        System.out.println("Herói Status: \n Vida: " + heroi.getVida() + "\n Ataque: " + heroi.getAtaque() + "\n Defesa: " + heroi.getDefesa());
        if (heroi.getMaoDireita() == null){
            System.out.println(" Mão Direita: vazio");
        }else{
            System.out.println(" Mão Direita: " + heroi.getMaoDireita().getTipo());
        }
        if (heroi.getMaoEsquerda() == null){
            System.out.println(" Mão Esquerda: Vazio");
        }else {
            System.out.println(" Mão Esquerda: " + heroi.getMaoEsquerda().getTipo());
        }
        if(heroi.getAjudante() == null){
            System.out.println(" Ajudante: Ninguém");
        }else {
            System.out.println(" Ajudante: " + heroi.getAjudante().getTipo());
        }

        for (int i = 0; i < this.numeroLinhas; i++)
        {
            for (int j = 0; j < this.numeroColunas; j++)
            {
                System.out.print(this.matriz[i][j]);
            }
            System.out.println();
        }
    }

    public Boolean encontraSaida(int x, int y)
    {
        if (this.heroi.getVida() <= 0)
            return false;
        if (this.matriz[x][y] == '=')
            return true;
        switch (this.matriz[x][y])
        {
            case '?':
                bichoPapaoExecute.executeAction(this.heroi);
                break;
            case '*':
                curupiraExecute.executeAction(this.heroi);
                break;
            case '^':
                duendeExecute.executeAction(this.heroi);
                break;
            case '&':
                anaoExecute.executeAction(this.heroi);
                break;
            case 'e':
                espadaExecute.executeAction(this.heroi);
                break;
            case 'd':
                escudoExecute.executeAction(this.heroi);
                break;
            case 'c':
                curaExecute.executeAction(this.heroi);
                break;

        }
        this.matriz[x][y] = '8';
        System.out.println("\033[H\033[2J");
        this.imprimeMapa();

        try {
            Thread.sleep(500);
        } catch (InterruptedException e){
            Thread.currentThread().interrupt();
            e.printStackTrace();
        }
        //backtracking
        //politica de visita
        //1.vou para direita
        //2.vou para baixo
        //3.vou para esquerda
        //4.vou para cima
        if (this.matriz[x+1][y] != '#' && this.matriz[x+1][y] != '8')
            if (encontraSaida(x+1,y) == true)
                return true;

        if (this.matriz[x][y+1] != '#' && this.matriz[x][y+1] != '8')
            if (encontraSaida(x,y+1) == true)
                return true;

        if (this.matriz[x-1][y] != '#' && this.matriz[x-1][y] != '8')
            if (encontraSaida(x-1,y) == true)
                return true;

        if (this.matriz[x][y-1] != '#' && this.matriz[x][y-1] != '8')
            if (encontraSaida(x,y-1) == true)
                return true;

        return false;
    }

    private void alocaMatriz()
    {
        this.matriz = new char[this.numeroLinhas][this.numeroColunas];
    }
}
