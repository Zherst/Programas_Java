import java.util.Scanner;

public interface Ajudante {

    Scanner scanner = new Scanner(System.in);

    default void ofereceAjuda(Heroi heroi){

        System.out.println("\033[H\033[2J");

        cumprimento();
        String resposta = scanner.nextLine().trim().toLowerCase();

        if (resposta.equals("s")) {
            if (heroi.getAjudante() == null) {
                heroi.setAjudante(this);
                System.out.println(getTipo() + "se juntou ao herói.");
            } else {
                System.out.println("Herói substituiu o ajudante " + heroi.getAjudante() + " pelo " + getTipo() +".");
                heroi.setAjudante(this);
            }
        }else if(resposta.equals("n")){
            System.out.println("Muito bem, te desejo sorte em sua aventura.");
        }else {
            System.out.println("Não entendi sua resposta.");
            ofereceAjuda(heroi);
        }

    }

    public void AcaoMonstro(Monstro monstro);

    public void AcaoHeroi(Heroi heroi);

    public void cumprimento();

    public String getTipo();


}
