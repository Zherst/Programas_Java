public class AjudanteExecute {
    private final AjudanteFactory factory;

    public AjudanteExecute(AjudanteFactory factory){
        this.factory = factory;
    }

    public void executeAction(Heroi heroi){
        factory.execute(heroi);
    }
}
