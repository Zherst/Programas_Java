public abstract class AjudanteFactory {
    public void execute(Heroi heroi){
        Ajudante a = criarAjudante();
        a.ofereceAjuda(heroi);
    }
    public abstract Ajudante criarAjudante();
}
