
public class Anao implements Ajudante{

    public void AcaoMonstro(Monstro monstro){
        System.out.println("Monstro recebeu +35% Vida");
        if(monstro instanceof Entidade){
            Entidade e = (Entidade) monstro;
            e.setVida(e.getVida() + (int)(e.getVida() * 0.35f));
        }
    };

    public void AcaoHeroi(Heroi heroi){
        System.out.println("Herói recebeu +85% Ataque");
        heroi.setAtaque(heroi.getAtaque() + (int)(heroi.getAtaque() * 0.85f));
    };

    public void cumprimento(){
        System.out.println("Olá nobre Herói, sou um Anão, necessita da ajuda do meu martelo? Sou capaz de aumentar seu ataque em 85%, mas aumento a vida do próximo monstros em 35%. Aceita?(s/n)");
    };

    public String getTipo(){ return "Anão"; };

}
