public class AnaoFactory extends AjudanteFactory{
    @Override
    public Ajudante criarAjudante(){
        return new Anao();
    }
}
