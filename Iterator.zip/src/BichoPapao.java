public class BichoPapao extends Entidade implements Monstro {

    BichoPapao() {
        super(5,5,5);
    }

    public void aplicaHabilidade(){
        this.setDefesa(this.getVida() + (int)(getVida() * 0.15f));
    }

    public String getDescricao(){
        return "Batalha contra Bicho Papão, Bonus: +15% Vida";
    }
}
