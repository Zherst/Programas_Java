public class BichoPapaoFactory extends MonstroFactory {
    @Override
    public Monstro criarMonstro() {
        return new BichoPapao();
    }
}
