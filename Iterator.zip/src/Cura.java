public class Cura extends Item{

    Cura(){
        super(EnumBonusItem.BONUS_CURA);
    }
    public void aplicaBonusHeroi(Heroi heroi) { heroi.setVida(heroi.getVida() + getBonus()); }
    public void retirarBonusHeroi(Heroi heroi) { }
    public void imprimeDescricao() { System.out.println("o Herói encontrou uma Cura, Ela aumenta a Vida em +" + getBonus() + " pontos, deseja apanhá-la"); }
    public String getTipo() { return "Cura"; }
}
