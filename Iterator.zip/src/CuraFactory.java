public class CuraFactory extends ItemFactory{
    @Override
    public Item criarItem() {
        return new Cura();
    }
}
