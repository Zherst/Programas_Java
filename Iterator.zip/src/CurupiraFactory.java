public class CurupiraFactory extends MonstroFactory{
    @Override
    public Monstro criarMonstro() {
        return new Curupira();
    }
}
