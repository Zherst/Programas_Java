
public class Duende implements Ajudante{

    public void AcaoMonstro(Monstro monstro){
        System.out.println("Monstro perdeu -50% Vida");
        if(monstro instanceof Entidade){
            Entidade e = (Entidade) monstro;
            e.setVida(e.getVida() - (int)(e.getVida() * 0.5f));
        }
    };

    public void AcaoHeroi(Heroi heroi){
        System.out.println("Herói perdeu -10% Vida");
        heroi.setAtaque(heroi.getAtaque() + (int)(heroi.getAtaque() * 0.1f));
    };

    public void cumprimento(){
        System.out.println("Olá Herói, eu sou um Duende, Queres da minha ajuda? Sou capaz de reduzir a vida do próximo monstro em 50%, a troca de um redução de 10% da vida atual. Aceitas?(s/n)");
    };

    public String getTipo(){ return "Duende"; };

}
