public class DuendeFactory extends AjudanteFactory{
    @Override
    public Ajudante criarAjudante() {
        return new Duende();
    }
}
