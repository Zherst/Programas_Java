public abstract class EntidadeFactory {
    public abstract Entidade criarEntidade();
}
