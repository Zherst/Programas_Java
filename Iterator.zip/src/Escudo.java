public class Escudo extends Item{

    Escudo(){
        super(EnumBonusItem.BONUS_ESCUDO);

    }
    public void aplicaBonusHeroi(Heroi heroi)
    {
        heroi.setDefesa(heroi.getDefesa() + getBonus());
    }
    public void retirarBonusHeroi(Heroi heroi)
    {
        heroi.setDefesa(heroi.getDefesa() - getBonus());
    }
    public void imprimeDescricao() { System.out.println("o Herói encontrou um Escudo, Ele aumenta a Defesa em +" + getBonus() + " pontos, deseja apanhá-la"); }
    public String getTipo() { return "Escudo"; }
}
