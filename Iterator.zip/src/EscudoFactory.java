public class EscudoFactory extends ItemFactory{
    @Override
    public Item criarItem() {
        return new Escudo();
    }
}
