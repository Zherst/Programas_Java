public class Espada extends Item{

    Espada(){
        super(EnumBonusItem.BONUS_ESPADA);
    }
    public void aplicaBonusHeroi(Heroi heroi) { heroi.setAtaque(heroi.getAtaque() + getBonus()); }
    public void retirarBonusHeroi(Heroi heroi) { heroi.setAtaque(heroi.getAtaque() - getBonus()); }
    public void imprimeDescricao() { System.out.println("o Herói encontrou uma Espada, Ela aumenta o Ataque em +" + getBonus() + " pontos, deseja apanhá-la"); }
    public String getTipo() {return "Espada";}
}
