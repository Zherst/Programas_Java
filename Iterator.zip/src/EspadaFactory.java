public class EspadaFactory extends ItemFactory{
    @Override
    public Item criarItem() { return new Espada(); }
}
