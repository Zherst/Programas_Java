public class Heroi extends Entidade {
    private Item maoEsquerda = null;
    private Item maoDireita = null;
    private Mochila mochila = new Mochila();

    private Ajudante ajudante;

    Heroi(){ super(5,5,5);}

    void setMaoEsquerda(Item item){ maoEsquerda = item;}
    void setMaoDireita(Item item){ maoDireita = item;}
    Item getMaoEsquerda() { return maoEsquerda;}
    Item getMaoDireita() { return maoDireita;}

    void setAjudante(Ajudante a) { ajudante = a; }
    Ajudante getAjudante() { return ajudante;}

    Mochila getMochila() { return mochila;}

}
