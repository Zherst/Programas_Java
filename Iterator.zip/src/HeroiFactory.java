public class HeroiFactory extends EntidadeFactory {
    @Override
    public Entidade criarEntidade() {
        return new Heroi();
    }
}
