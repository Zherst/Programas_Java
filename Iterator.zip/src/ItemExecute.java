public class ItemExecute {
    private final ItemFactory factory;

    public ItemExecute(ItemFactory factory){
        this.factory = factory;
    }

    public void executeAction(Heroi heroi){
        factory.execute(heroi);
    }
}
