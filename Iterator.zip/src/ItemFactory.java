public abstract class ItemFactory {
    public void execute(Heroi heroi){
        Item i = criarItem();
        i.juntar(heroi);
    }
    public abstract Item criarItem();
}
