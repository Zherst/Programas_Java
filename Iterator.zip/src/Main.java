import java.io.IOException;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);



        try {
            Mapa map = null;
            Mapa map1 = new Mapa("C:\\Users\\renat\\IdeaProjects\\Jogo_Labirinto_ES\\src\\mapa.txt", 17,21);
            Mapa map2 = new Mapa("C:\\Users\\renat\\IdeaProjects\\Jogo_Labirinto_ES\\src\\mapa2.txt", 17,21);


            System.out.println("Escolha o Mapa: 1 2");
            String escolha = scanner.nextLine().trim();

            switch (escolha){
                case "1":
                    map = map1;
                    break;
                case "2":
                    map = map2;
                    break;
                default:
                    System.out.println("Opção inválida! Escolhendo mapa 1 por padrão.");
                    map = map1;
            }


            map.imprimeMapa();

            if(map.encontraSaida(1,1) == true){
                System.out.println("Vc Venceu");
                return;
            }
            System.out.println("Vc Perdeu");
        }catch (Exception e){
            e.printStackTrace();
        }

    }
}