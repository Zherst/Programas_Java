import java.util.ArrayList;
import java.util.List;

public class Mochila {
    private List<Item> itens;

    public Mochila(){
        this.itens = new ArrayList<>();
    }

    public void adicionar(Item item){
        itens.add(item);
        System.out.println(item.getClass().getName() + " adicionado à mochila");
    }

    public void remover(Item item){
        itens.remove(item);
        System.out.println(item.getClass().getName() + " removido da mochila");
    }

    public ItemIterator criarIterador(){
        return new MochilaIterador(itens);
    }

    public void listarItens(){
        ItemIterator iter = criarIterador();
        while (iter.hasNext()){
            Item item = iter.next();
            System.out.print(" " + item.getClass().getName() + " ");
        }
        System.out.println();
    }
}
