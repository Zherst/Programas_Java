import java.util.List;

public class MochilaIterador implements ItemIterator{
    private List<Item> itens;
    private int posicao = 0;

    public MochilaIterador(List<Item> itens){
        this.itens = itens;
    }

    @Override
    public boolean hasNext() {
        return posicao < itens.size();
    }

    @Override
    public Item next() {
        if (this.hasNext()){
            return itens.get(posicao++);
        }
        return null;
    }
}
