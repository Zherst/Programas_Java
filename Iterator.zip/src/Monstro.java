public interface Monstro {

    default void batalha(Heroi heroi){
        if (this instanceof Entidade) {

            Entidade monstro = (Entidade) this;

            System.out.println(getDescricao());
            this.aplicaHabilidade();

            try{
                Thread.sleep(2000);
            }catch (Exception e){
                e.printStackTrace();
            }


            if (heroi.getAjudante() != null) {
                System.out.println("\033[H\033[2J");
                heroi.getAjudante().AcaoHeroi(heroi);
                heroi.getAjudante().AcaoMonstro(this);
                System.out.println(heroi.getAjudante().getTipo() + " Saiu da Batalha ");
                heroi.setAjudante(null);
                try{
                    Thread.sleep(2000);
                }catch (Exception e) {
                    e.printStackTrace();
                }
            }

            while (true){
                System.out.println("\033[H\033[2J");

                //Turno Herói
                int ataqueHeroi = heroi.getAtaque() - monstro.defesa;
                if (ataqueHeroi < 0) ataqueHeroi = 0;
                monstro.setVida(monstro.getVida() - ataqueHeroi);

                System.out.println("Heroi Atacou!!");
                System.out.println("Herói Vida: " + heroi.getVida());
                System.out.println("Monstro Vida: " + monstro.getVida());
                System.out.flush();


                try{
                    Thread.sleep(2000);
                }catch (Exception e) {
                    e.printStackTrace();
                }
                if (monstro.getVida() <0) return;
                //Turno Monstro

                System.out.println("\033[H\033[2J");
                int ataqueMonstro = monstro.getAtaque() - heroi.defesa;
                if (ataqueMonstro < 0) ataqueMonstro = 0;
                heroi.setVida(heroi.getVida() - ataqueMonstro);

                System.out.println("Monstro Atacou!!");
                System.out.println("Herói Vida: " + heroi.getVida());
                System.out.println("Monstro Vida: " + monstro.getVida());
                System.out.flush();

                try{
                    Thread.sleep(2000);
                }catch (Exception e) {
                    e.printStackTrace();
                }
                if (heroi.getVida() <= 0) return;
            }

        }
    }

    void aplicaHabilidade();

    String getDescricao();
}
