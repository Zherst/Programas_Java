public class MonstroExecute {
    private final MonstroFactory factory;

    public MonstroExecute(MonstroFactory factory){
        this.factory = factory;
    }

    public void executeAction(Heroi heroi){
        factory.execute(heroi);
    }
}
