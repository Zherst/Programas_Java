public abstract class MonstroFactory {
    public void execute(Heroi heroi){
        Monstro m = criarMonstro();
        m.batalha(heroi);
    }
    public abstract Monstro criarMonstro();
}
