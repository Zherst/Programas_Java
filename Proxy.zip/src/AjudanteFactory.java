public abstract class AjudanteFactory {
    public void execute(Heroi heroi){
        Ajudante a = criarAjudante();
        a.ofereceAjuda(heroi);
        ProxyAjudante.Log(a);
    }
    public abstract Ajudante criarAjudante();
}
