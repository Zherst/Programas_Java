public class BichoPapao extends Entidade implements Monstro {

    BichoPapao() {
        super(15,25,70);
    }

    public void aplicaHabilidade(){
        this.setDefesa(this.getVida() + (int)(getVida() * 0.15f));
    }

    public String getDescricao(){
        return "Batalha contra Bicho Papão, Bonus: +15% Vida";
    }

    @Override
    public String getTipo() {
        return "Bicho Papão";
    }
}
