public class Curupira extends Entidade implements Monstro {

    Curupira() {
        super(25,25,50);
    }

    public void aplicaHabilidade(){
        this.setAtaque(this.getAtaque() + (int)(getAtaque() * 0.15f));
    }

    public String getDescricao(){
        return "Batalha contra Curupira, Bonus: +15% Ataque";
    }

    @Override
    public String getTipo() {
        return "Curupira";
    }
}
