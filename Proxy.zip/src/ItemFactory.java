public abstract class ItemFactory {
    public void execute(Heroi heroi){
        Item i = criarItem();
        i.juntar(heroi);
        ProxyItem.Log(i);
    }
    public abstract Item criarItem();
}
