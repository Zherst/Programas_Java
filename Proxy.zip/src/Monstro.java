import java.util.Random;

public interface Monstro {

    default void batalha(Heroi heroi){
        if (this instanceof Entidade) {

            Entidade monstro = (Entidade) this;

            System.out.println(getDescricao());
            this.aplicaHabilidade();

            try{
                Thread.sleep(2000);
            }catch (Exception e){
                e.printStackTrace();
            }


            if (heroi.getAjudante() != null) {
                System.out.println("\033[H\033[2J");
                heroi.getAjudante().AcaoHeroi(heroi);
                heroi.getAjudante().AcaoMonstro(this);
                System.out.println(heroi.getAjudante().getTipo() + " Saiu da Batalha ");
                heroi.setAjudante(null);
                try{
                    Thread.sleep(2000);
                }catch (Exception e) {
                    e.printStackTrace();
                }
            }

            while (true){
                System.out.println("\033[H\033[2J");

                //Turno Herói
                ataque(heroi,monstro);
                printStatus(heroi,monstro);
                try{
                    Thread.sleep(2000);
                }catch (Exception e) {
                    e.printStackTrace();
                }
                if (monstro.getVida() <0) return;
                //Turno Monstro

                ataque(monstro,heroi);
                printStatus(heroi,monstro);
                try{
                    Thread.sleep(2000);
                }catch (Exception e) {
                    e.printStackTrace();
                }
                if (heroi.getVida() <= 0) return;
            }

        }
    }
    private void ataque(Entidade attacker, Entidade defender){
        System.out.println("");
        double rnd = (int)(Math.random() * 100);
        String attackerName;
        if(attacker instanceof Monstro){
            attackerName = getTipo();
        }
        else{
            attackerName = "Herói";
        }
        if (defender.getDefesa() <= rnd ){
            if (attacker.getAtaque() <= 0)
                return;
            defender.setVida(defender.getVida() - attacker.getAtaque());
            System.out.println(attackerName + " Atacou!!");
        }
        else {
            System.out.println(attackerName + " errou o ataque!!!");
        }
    }
    private void printStatus(Entidade heroi, Entidade monstro) {
        System.out.println("Herói Vida: " + heroi.getVida());
        System.out.println(getTipo() + " Vida: " + monstro.getVida());
        System.out.flush();
    }

    void aplicaHabilidade();

    String getDescricao();

    String getTipo();
}
