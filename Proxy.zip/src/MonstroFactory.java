public abstract class MonstroFactory {
    public void execute(Heroi heroi){
        Monstro m = criarMonstro();
        m.batalha(heroi);
        ProxyMonstro.Log(m);
    }
    public abstract Monstro criarMonstro();
}
