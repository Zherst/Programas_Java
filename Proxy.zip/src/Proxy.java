import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public interface Proxy {
    String LOG_file = "C:\\Users\\renat\\IdeaProjects\\Jogo_Labirinto_ES\\src\\Log.txt";

    static void RegistrarLog(String message){
        LocalDateTime agora = LocalDateTime.now();
        DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss", new Locale("pt","BR"));
        String dataFormatada = agora.format(formatador);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOG_file,true))) {
            String log = "[" + dataFormatada + "]" + message;
            writer.write(log);
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Erro ao Registrar log: " + e.getMessage());
        }
    };
}
