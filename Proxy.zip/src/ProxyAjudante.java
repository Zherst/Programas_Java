public class ProxyAjudante {

    public static void Log(Ajudante ajudante)
    {
        var message = "Herói se aproximou de um " + ajudante.getTipo();
        Proxy.RegistrarLog(message);
    }
}
