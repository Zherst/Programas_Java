public class ProxyItem{

    public static void Log(Item item)
    {
        var message = "Herói encontrou um " + item.getTipo();
        Proxy.RegistrarLog(message);
    }
}
