public class ProxyLose {

    public static void Log()
    {
        var message = "O Herói morreu";
        Proxy.RegistrarLog(message);
    }
}
