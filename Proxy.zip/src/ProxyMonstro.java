public class ProxyMonstro {

    public static void Log(Monstro monstro)
    {
        var message = "Herói vai batalhar contra um " + monstro.getTipo();
        Proxy.RegistrarLog(message);
    }
}
