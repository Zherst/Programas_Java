public class ProxyWin {

    public static void Log()
    {
        var message = "Herói encontrou a saída do labirinto";
        Proxy.RegistrarLog(message);
    }
}
